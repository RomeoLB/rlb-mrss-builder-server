console.log('Control script loaded v1.5');

let value; // Global variable to hold the validated value

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('setButton').addEventListener('click', validateInput);
    document.getElementById('updateFeedButton').addEventListener('click', updateFeed);
});

function sendUdpMessage(message) {
    fetch('/send-message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message }),
    })
    .then(response => response.json())
    .then(data => console.log('Success:', data))
    .catch((error) => console.error('Error:', error));
}

function validateInput() {
    const inputElement = document.getElementById('textInput');
    const tempValue = parseInt(inputElement.value, 10); // Temporary value for validation
    const errorMessageElement = document.getElementById('errorMessage');
    const successMessageElement = document.getElementById('successMessage');

    // Clear previous messages
    errorMessageElement.textContent = '';
    successMessageElement.textContent = '';

    // Check if the value is a number and between 1 and 999
    if (!isNaN(tempValue) && tempValue >= 1 && tempValue <= 999) {
        value = tempValue; // Set the global variable to the validated value
        successMessageElement.textContent = `Valid input: ${value} seconds`;
    } else {
        // Invalid input; display an error message
        errorMessageElement.textContent = 'Invalid Input - Please enter a number between 1 and 999.';
        value = undefined; // Clear the global variable on invalid input
    }
}

function updateFeed() {
    // Check if the value has been set
    const errorMessageUpdateElement = document.getElementById('errorMessageUpdate');
    const successMessageUpdateElement = document.getElementById('successMessageUpdate');

    errorMessageUpdateElement.textContent = '';
    successMessageUpdateElement.textContent = '';

    if (value !== undefined) {
        // Create the message with the prefix "update:"
        const message = `update:${value}`;
        // Call the sendUdpMessage function with the message
        sendUdpMessage(message);
        successMessageUpdateElement.textContent = `Request to generate new MRSS feed with image display duration of ${value} seconds`;
    } else {
        // Show an error message if the value is not set
        errorMessageUpdateElement.textContent = 'You must enter a value in the above textfield then click the "Set" button. Enter the number 1 in the above textfield if you do not have any images in your MRSS feed.';
    }
}